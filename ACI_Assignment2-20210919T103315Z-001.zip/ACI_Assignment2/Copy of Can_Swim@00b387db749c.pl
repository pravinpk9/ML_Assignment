type(ungulate, animal).
type(fish, animal).

is_a(zebra, ungulate).
is_a(herring, fish).
is_a(shark, fish).

lives(zebra, on_land).
lives(shark, in_water).
lives(herring, in_water).

can_swim(Y) :- 
  type(X, animal) ,
  is_a(Y, X) ,
  lives(Y, in_water). 